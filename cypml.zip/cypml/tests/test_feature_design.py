Test Featurizer
