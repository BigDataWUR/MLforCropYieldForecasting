Test Feature Selector
