Test Algorithm Evaluator
